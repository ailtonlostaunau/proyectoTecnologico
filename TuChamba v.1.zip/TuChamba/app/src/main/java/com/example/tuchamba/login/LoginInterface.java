package com.example.tuchamba.login;

public interface LoginInterface {
    //Realiza la accion una vez que se selecciona una opcion o boton
    interface View{

        void habilitarInputs();
        void deshabilitarInputs();

        void mostrarProgreso();
        void ocultarProgreso();

        void validarLogin();
        boolean esValidoEmail();
        boolean esValidoClave();

        void onLogin();
        void onError(String error);
    }

    //Realiza la accion una vez que se selecciona una opcion o boton
    interface Presentar{
        void onDestroy();
        void toLogin(String correo, String clave);


    }

    //Realiza la transaccion de una funcion
    interface Modelo{
        void doLogin(String correo, String clave);
    }

    //Indica si la informacion obtenida es correcta o no
    interface Respuesta{
        void onExito();
        void onError(String error);

    }
}
